"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const MainDatabase_1 = __importDefault(require("./MainDatabase"));
class VideoDB extends MainDatabase_1.default {
    getVideoById(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield this.connection.raw(`SELECT * FROM future_tube_videos WHERE id = "${id}"`);
                return result[0][0];
            }
            catch (err) {
                throw new Error(err.sqlMessage);
            }
        });
    }
    uploadVideo(video) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.connection.raw(`INSERT into future_tube_videos values(
                    '${video.getId()}',     
                    '${video.getTitle()}',
                    '${video.getDescription()}',
                    '${video.getUrl()}',
                    '${video.getUserId()}'
            )`);
            }
            catch (err) {
                throw new Error(err.sqlMessage);
            }
        });
    }
    getUserUploads(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                const result = yield this.connection.raw(`SELECT * FROM future_tube_videos WHERE user_id = "${id}"`);
                return result[0];
            }
            catch (err) {
                throw new Error(err.sqlMessage);
            }
        });
    }
    editVideo(id, newTitle, newDescription) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.connection.raw(`UPDATE future_tube_videos SET title = "${newTitle}" WHERE id = "${id}";`);
                yield this.connection.raw(`UPDATE future_tube_videos SET description = "${newDescription}" WHERE id = "${id}";`);
            }
            catch (err) {
                throw new Error(err.sqlMessage);
            }
        });
    }
    deleteVideo(id) {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                yield this.connection.raw(`DELETE FROM future_tube_videos WHERE id = "${id}";`);
            }
            catch (err) {
                throw new Error(err.sqlMessage);
            }
        });
    }
    getAllVideos(page) {
        return __awaiter(this, void 0, void 0, function* () {
            const offset = 10 * (page - 1);
            try {
                const result = yield this.connection.raw(`SELECT id, title, url FROM future_tube_videos 
                LIMIT 10 OFFSET ${offset}`);
                return result[0];
            }
            catch (err) {
                throw new Error(err.sqlMessage);
            }
        });
    }
}
exports.default = VideoDB;
