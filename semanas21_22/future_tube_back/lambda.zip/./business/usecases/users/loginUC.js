"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const user_1 = __importDefault(require("../../entities/user"));
class LoginUC {
    constructor(database) {
        this.database = database;
    }
    execute(token, email, password) {
        return __awaiter(this, void 0, void 0, function* () {
            let user;
            if (token) {
                const id = user_1.default.getTokenData(token).id;
                user = yield this.database.getUser(id);
            }
            else {
                if (!email || !password) {
                    throw new Error("Dados insufucuentes");
                }
                user = yield this.database.getUser(email);
                const passwordIsCorrect = user_1.default.checkPassword(password, user.password);
                if (!passwordIsCorrect) {
                    throw new Error("Usuário ou senha incorretos");
                }
            }
            return {
                message: "Usuário logado",
                token: user_1.default.generateToken(user.id),
                user: {
                    id: user.id,
                    name: user.name,
                    profilePicture: user.profile_picture
                }
            };
        });
    }
}
exports.default = LoginUC;
